import pytest
from utils import sumvalues, meannvalue, minvalue, maxvalue, medianvalue, countvalue, sorted_array

# Utils tests
# Sum values tests
def test_sumvalue():
    # Successful tests
    assert sumvalues(values=[]) == 0
    assert sumvalues(values=[1,2,3,4,5,6,7]) == 28
    assert sumvalues(values=['1','11','65']) == 77
    # Test errors
    with pytest.raises(ValueError):
        sumvalues(values=['1','hello','65'])

# Maximum value test
def test_maxvalue():
    # Successful tests
    assert maxvalue(values=[1,2,3,4,5,6,7]) == 6
    assert maxvalue(values=['1','11','65']) == 2
    # Test errors
    with pytest.raises(ValueError):
        maxvalue(values=['1','hello','65'])

# # Minimum value tests
def test_minvalue():
    # Successful tests
    assert minvalue(values=[1,2,3,4,5,6,7]) == 0
    assert minvalue(values=['11','1','65']) == 1
    # Test errors
    with pytest.raises(ValueError):
        minvalue(values=['1','hello','65'])    

# Mean values tests
def test_meannvalue():
    # Successful tests
    assert meannvalue(values=[1,2,3,4,5,6,7,8]) == 4.5
    assert meannvalue(values=['11','1','66']) == 26
    # Test errors
    with pytest.raises(ValueError):
        meannvalue(values=['1','hello','65'])
    with pytest.raises(ZeroDivisionError):
        meannvalue(values=[])

# Median values tests
def test_medianvalue():
    # Successful tests
    assert medianvalue(values=[1,2,8,4,5,6,7,3]) == 4.5
    assert medianvalue(values=['11','1','65']) == 11
    # Test errors
    with pytest.raises(ValueError):
        medianvalue(values=['1','hello','65','22'])

# Count values test
def test_countvalue():
    # Successful tests
    assert countvalue(values=[1,2,8,4,5,6,4,2,3],x=2) == 2
    assert countvalue(values=['a','b','c','c','a','c'],x='a') == 2
    assert countvalue(values=['a','b','c','c'],x=2) == 0
    assert countvalue(values=[],x=2) == 0

# Sort values test
def test_sorted_array():
    # Successful tests
    assert sorted_array(arr=[['2',2],['3',3],['1',1]]) == [['3',3],['2',2],['1',1]]
    # Test errors
    with pytest.raises(TypeError):
        sorted_array(arr=[2,3,1])

