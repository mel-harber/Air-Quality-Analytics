# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification
import numpy as np

def sumvalues(values):
    """
    This function take a list of values as an input and loops through each item adding them as it does. An error 
    is provided if a non numerical piece of data is found, if not the sum of all the items in the list is output
    @param values: list of numbers 
    @return nSum: the sum of all the value in the list
    """    
    nSum = 0
    try:
        # Iterate through each item in the list
        for item in values:
            # Add the current value to the overall sum
            nSum += float(item)
        return nSum
    # Raise exception if a non numerical piece of data is found
    except ValueError:
        raise ValueError("Non numerical data found in list")


def maxvalue(values):
    """
    This function take a list of values as an input finds the largest value in the list. An error is provided if 
    a non numerical piece of data is found, if not the index of the largest value in the list is returned
    @param values: list of numbers 
    @return np.where(values == nMax)[0][0]: the index of the largest value in the list
    """    
    nMax = 0
    # Convert list to floats
    values = np.array(values).astype(float)
    try:
        # Iterate through each item in the list
        for item in values:
            # If larger make current value the new max
            if item > nMax:
                nMax = item
         # Return index of the maximum value 
        return np.where(values == nMax)[0][0]
    # Raise exception if a non numerical piece of data is found
    except ValueError:
        raise ValueError("Non numerical data found in list")


def minvalue(values):
    """
    This function take a list of values as an input finds the smallest value in the list. An error is provided if
    a non numerical piece of data is found, if not the index of the smallest value in the list is returned
    @param values: list of numbers 
    @return np.where(values == nMin)[0][0]: the index of the smallest value in the list
    """    
    nMin = float(values[0])
    # Convert list to floats
    values = np.array(values).astype(float)
    try:
        # Iterate through each item in the list
        for item in values:
            if item < nMin:
                nMin = item
        # Return index of the minimum value 
        return np.where(values == nMin)[0][0]
    # Raise exception if a non numerical piece of data is found
    except ValueError:
        raise ValueError("Non numerical data found in list")


def meannvalue(values):
    """
    This function take a list of values as an input finds the mean of the values. An error is provided if
    a non numerical piece of data is found, if not the mean value is returned
    @param values: list of numbers 
    @return nMean: the mean of the list 
    """    
    try:
        # Call sumvalues function to add all the values together
        nSum = sumvalues(values)
        nMean = nSum/len(values)
        return nMean
    # Raise exception if a non numerical piece of data is found
    except ValueError:
        raise ValueError("Non numerical data found in list")
    except ZeroDivisionError:
        raise ZeroDivisionError('No data in list')


def medianvalue(values):
    """#
    This function take a list of values as an input and returns the median of them
    @param values: list of numbers 
    @return float(sMedian): the median value in the list as a float
    """
    try:
        # Converts array to numpy array of floats
        values = np.array(values).astype(float)
        sortedValues = sorted(values)
        # Remove any data values that aren't numbers
        sortedValues = [value for value in sortedValues if value != 'No data']
        # Select middle value of average of middle values
        if len(sortedValues)%2 == 1:
            sMedian = sortedValues[(len(sortedValues))//2]
        else:
            sMedian = (float(sortedValues[(len(sortedValues))//2]) + float(sortedValues[((len(sortedValues))//2)-1])) / 2 
        return float(sMedian)
    # Raise exception if a non numerical piece of data is found
    except ValueError:
        raise ValueError("Non numerical data found in list")


def countvalue(values,x):
    """
    This function takes a list and a value as an input and counts the occurences of the value in the list and 
    outputs the count
    @param values: list of numbers 
    @param x: a variable
    @return nMean: the number of occureces of the variable in the list 
    """    
    nCount = 0
    # Loops through each value in the list
    for item in values:
        if item == x:
            # Increments the count
            nCount += 1        
    return nCount


def sorted_array(arr):
    """
    This funtion takes an array as it's input and implements and insertion sort to return the sorted array
    @param arr: 2d array values
    @return arr: list of sorted values 
    """
    try:
        # Loops through the array
        for i in range(1, len(arr)):
                tmp = arr[i]
                k = i
                # Checks value to be sorted by 
                while k > 0 and tmp[1] > arr[k - 1][1]:
                    arr[k] = arr[k - 1]
                    # Reduce k by 1
                    k -= 1
                arr[k] = tmp
        return arr
    except TypeError:
        raise TypeError("Incorrect data type passed")
