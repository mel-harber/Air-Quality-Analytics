# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification

from utils import *

def daily_average(data, monitoring_station, pollutant):
    """
    This funtion takes in the dictionary of pollution data in London and the selected monitoring 
    station and pollutant and returns the average recording for each day
    @param data: dictionary of London pollution data
    @param monitoring_station: string of the selected monitoring station 
    @param pollutant: string of the selected pollutant
    @return list(dDailyReportAvg.values()): list of the daily averages for the selected monitoring station and pollutant
    """
    # Your code goes here
    # Select index based on pollutant passed to the function
    if pollutant == 'no':
        nIndex = 2
    elif pollutant == 'pm10':     
        nIndex = 3
    elif pollutant == 'pm25':
        nIndex = 4
    else:
        raise Exception("Invalid pollutant entered")
    # Select approptiate list of data from the dictionary based on the monitoring station
    aStationData = data[monitoring_station]
    dDailyReportAvg = {}
    # Loop through data in the station
    # Start loop at 1 not 0 so 'data' is not one of my keys
    for i in range(1,len(aStationData)):
        # Check day ins't already in dictionary
        if aStationData[i][0] in dDailyReportAvg:
            # Write pollutant data
            dDailyReportAvg[aStationData[i][0]].append(aStationData[i][nIndex])
            continue
        # Add to existing day in dictionary
        else: 
            dDailyReportAvg.update({aStationData[i][0]: [aStationData[i][nIndex]]})
    # Calculate the average for each day
    for j in dDailyReportAvg:
        avg = round(meannvalue(dDailyReportAvg[j]),2) 
        dDailyReportAvg[j] = avg
    # Return list of all the averages
    return list(dDailyReportAvg.values())


def daily_median(data, monitoring_station, pollutant):
    """
    This funtion takes in the dictionary of pollution data in London and the selected monitoring 
    station and pollutant and returns the daily median for each day
    @param data: dictionary of London pollution data
    @param monitoring_station: string of the selected monitoring station 
    @param pollutant: string of the selected pollutant
    @return list(dDailyReportMed.values()): list of the daily medians for the selected monitoring station and pollutant
    """
    # Your code goes here
    # Select index based on pollutant passed to the function
    if pollutant == 'no':
        nIndex = 2
    elif pollutant == 'pm10':     
        nIndex = 3
    elif pollutant == 'pm25':
        nIndex = 4
    else:
        raise Exception("Invalid pollutant entered")
    # Select approptiate list of data from the dictionary based on the monitoring station
    aStationData = data[monitoring_station]
    dDailyReportMed = {}
    # Loop through data in the station
    # Start loop at 1 not 0 so 'data' is not one of my keys
    for i in range(1,len(aStationData)):
        # Check day ins't already in dictionary
        if aStationData[i][0] in dDailyReportMed:
            # Write pollutant data
            dDailyReportMed[aStationData[i][0]].append(aStationData[i][nIndex])
            continue
        # Add to existing day in dictionary
        else: 
            dDailyReportMed.update({aStationData[i][0]: [aStationData[i][nIndex]]})
    # Calculate the median for each day
    for j in dDailyReportMed:
        avg = round(float(medianvalue(dDailyReportMed[j])),2) 
        dDailyReportMed[j] = avg
    # Return list of all the medians
    return list(dDailyReportMed.values())


def hourly_average(data, monitoring_station, pollutant):
    """
    This funtion takes in the dictionary of pollution data in London and the selected monitoring 
    station and pollutant and returns the average for each hour of the day
    @param data: dictionary of London pollution data
    @param monitoring_station: string of the selected monitoring station 
    @param pollutant: string of the selected pollutant
    @return list(dHourlyAvg.values()): list of the hourly averages for the selected monitoring station and pollutant
    """
    # Your code goes here
    # Select index based on pollutant passed to the function
    if pollutant == 'no':
        nIndex = 2
    elif pollutant == 'pm10':     
        nIndex = 3
    elif pollutant == 'pm25':
        nIndex = 4
    else:
        raise Exception("Invalid pollutant entered")
    # Select approptiate list of data from the dictionary based on the monitoring station
    aStationData = data[monitoring_station]
    dHourlyAvg = {}
    # Loop through data in the station
    # Start loop at 1 not 0 so 'data' is not one of my keys
    for i in range(1,len(aStationData)):
        # Check hour ins't already in dictionary
        if aStationData[i][1] in dHourlyAvg:
            # Write pollutant data
            dHourlyAvg[aStationData[i][1]].append(aStationData[i][nIndex])
            continue
        # Add to existing hour in dictionary
        else: 
            dHourlyAvg.update({aStationData[i][1]: [aStationData[i][nIndex]]})
    # Calculate the average for each hour
    for j in dHourlyAvg:
        avg = round(meannvalue(dHourlyAvg[j]),2) 
        dHourlyAvg[j] = avg
    # Return list of all the averages
    return list(dHourlyAvg.values()) 


def monthly_average(data, monitoring_station, pollutant):
    """
    This funtion takes in the dictionary of pollution data in London and the selected monitoring 
    station and pollutant and returns the average pollution level for month
    @param data: dictionary of London pollution data
    @param monitoring_station: string of the selected monitoring station 
    @param pollutant: string of the selected pollutant
    @return list(dMonthlyAvg.values()): list of the monthly averages for the selected monitoring station and pollutant
    """
    # Your code goes here
    # Select index based on pollutant passed to the function
    if pollutant == 'no':
        nIndex = 2
    elif pollutant == 'pm10':     
        nIndex = 3
    elif pollutant == 'pm25':
        nIndex = 4
    else:
        raise Exception("Invalid pollutant entered")
    # Select approptiate list of data from the dictionary based on the monitoring station
    aStationData = data[monitoring_station]
    dMonthlyAvg = {}
    # Loop through data in the station
    # Start loop at 1 not 0 so 'data' is not one of my keys
    for i in range(1,len(aStationData)):
        # Check month ins't already in dictionary
        if (aStationData[i][0])[5:7] in dMonthlyAvg:
            # Write pollutant data
            dMonthlyAvg[(aStationData[i][0])[5:7]].append(aStationData[i][nIndex])
            continue
        # Add to existing month in dictionary
        else: 
            dMonthlyAvg.update({(aStationData[i][0])[5:7]: [aStationData[i][nIndex]]})
    # Calculate the average for each month
    for j in dMonthlyAvg:
        avg = round(meannvalue(dMonthlyAvg[j]),2) 
        dMonthlyAvg[j] = avg
    # Return list of all the averages
    return list(dMonthlyAvg.values()) 


def peak_hour_date(data, date, monitoring_station,pollutant):
    """
    This funtion takes in the dictionary of pollution data in London and the selected monitoring 
    station, pollutant and date, and returns the average pollution level for month
    @param data: dictionary of London pollution data
    @param date: string of selected date
    @param monitoring_station: string of the selected monitoring station 
    @param pollutant: string of the selected pollutant
    @return peakHour: string of the hour of the day with the highest pollution level
    @return maxValue: string of the highest pollution level of the day
    """
    # Your code goes here
    # Select index based on pollutant passed to the function
    if pollutant == 'no':
        nIndex = 2
    elif pollutant == 'pm10':     
        nIndex = 3
    elif pollutant == 'pm25':
        nIndex = 4
    else:
        raise Exception("Invalid pollutant entered")
    # Select approptiate list of data from the dictionary based on the monitoring station
    aStationData = data[monitoring_station]
    aDay = []
    # Loop through data in the station
    # Start loop at 1 not 0 so 'data' is not one of my keys
    for i in range(1,len(aStationData)):
        if aStationData[i][0] == date:
            aDay.append(aStationData[i][nIndex])
    # Call max fucntion from utils to find max value form each day
    maxIndex = maxvalue(aDay)
    maxValue = aDay[maxIndex]
    # Find peak hour in the required day
    for i in range(1,len(aStationData)):
        if aStationData[i][0] == date and aStationData[i][nIndex] == maxValue:
            peakHour = aStationData[i][1]
            break
    # Returns peak hour and maximum value of that day
    return peakHour, maxValue


def count_missing_data(data, monitoring_station,pollutant):
    """
    This funtion takes in the dictionary of pollution data in London and the selected monitoring 
    station and pollutant and returns the number of missing data points
    @param data: dictionary of London pollution data
    @param monitoring_station: string of the selected monitoring station 
    @param pollutant: string of the selected pollutant
    @return missingData: integer of the number of 'No data' entries in the data
    """
    # Your code goes here
    # Select approptiate list of data from the dictionary based on the monitoring station
    aStationData = data[monitoring_station]
    aRequiredData=[]
    # Select index based on pollutant passed to the function
    if pollutant == 'no':
        nIndex = 2
    elif pollutant == 'pm10':     
        nIndex = 3
    elif pollutant == 'pm25':
        nIndex = 4
    else:
        raise Exception("Invalid pollutant entered")
    # Loops through data points ignoring any that are't 'No data'
    for i in aStationData:
        if i[nIndex] == pollutant or i[nIndex] != 'No data':
            continue
        aRequiredData.append(i[nIndex])
    # Find the number of missing data points and returns it 
    missingData = len(aRequiredData)
    return missingData


def fill_missing_data(data, new_value, monitoring_station,pollutant):
    """
    This funtion takes in the dictionary of pollution data in London and the selected monitoring 
    station, new data point and pollutant and returns the new data dictionary
    @param data: dictionary of London pollution data
    @param new_value: integer of a new value to replace missing data
    @param monitoring_station: string of the selected monitoring station 
    @param pollutant: string of the selected pollutant
    @return data: dictionary with the new value replacing the missing data for the given monitoring station and pollutant
    """
    # Your code goes here
    # Select approptiate list of data from the dictionary based on the monitoring station
    aStationData = data[monitoring_station]
    # Select index based on pollutant passed to the function
    if pollutant == 'no':
        nIndex = 2
    elif pollutant == 'pm10':     
        nIndex = 3
    elif pollutant == 'pm25':
        nIndex = 4
    else:
        raise Exception("Invalid pollutant entered")
    # Replace all No data's with the new data point
    for i in aStationData:
        if i[nIndex] == 'No data':
            i[nIndex] = new_value
    data[monitoring_station] = aStationData
    return data
