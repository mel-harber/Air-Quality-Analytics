# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification.
# 
# This module will access data from the LondonAir Application Programming Interface (API)
# The API provides access to data to monitoring stations. 
# 
# You can access the API documentation here http://api.erg.ic.ac.uk/AirQuality/help
#

def get_live_data_from_api(site_code='MY1',species_code='NO',start_date=None,end_date=None):
    """
    Return data from the LondonAir API using its AirQuality API. 
    
    *** This function is provided as an example of how to retrieve data from the API. ***
    It requires the `requests` library which needs to be installed. 
    In order to use this function you first have to install the `requests` library.
    This code is provided as-is. 
    """
    import requests
    import datetime
    start_date = datetime.date.today() if start_date is None else start_date
    end_date = start_date + datetime.timedelta(days=1) if end_date is None else end_date
    
    
    endpoint = "https://api.erg.ic.ac.uk/AirQuality/Data/SiteSpecies/SiteCode={site_code}/SpeciesCode={species_code}/StartDate={start_date}/EndDate={end_date}/Json"
   
    url = endpoint.format(
        site_code = site_code,
        species_code = species_code,
        start_date = start_date,
        end_date = end_date
    )
    
    res = requests.get(url)
    return res.json()


def get_data_as_list():
    """
    This function calls the function that retrieves data from the API and converts them into a 2D my_dataay 
    containing date and time and the pollutant value
    @return my_list: 2D array of hours and pollution level
    """
    # Your code goes here
    # Calls function to read data from the API
    live_data = get_live_data_from_api()
    # Accesses data part of the dictionary returned by the function call
    main_data = live_data['RawAQData']['Data']
    # Create place holder for required values
    my_list = []
    for i in main_data:
        # Ignores any hours with no data
        if i['@Value'] == '':
            continue
        # Makes a mini my_dataay containg hour and pollutant level
        hour = [i['@MeasurementDateGMT'],float(i['@Value'])]
        # Adds mini my_dataay to main my_dataay to get all hours and values in a single my_dataay 
        my_list.append(hour)
    return my_list


def calc_variance():
    """
    This function reads the data from the API through the get_data_as_list fucntion and outputs the variace of 
    the pollutant level
    @return round(my_variance,2): float rounded to 2d.p. of the variance of the data set
    """
    # Your code goes here
    import statistics 
    # Call function to retrieve data
    my_data = get_data_as_list()
    numerical_data = []
    # Create list of all polutant values
    for i in my_data:
        numerical_data.append(i[1])
    # Calculates variance from list of values
    my_variance = statistics.variance(numerical_data)
    return round(my_variance,2)


def visualise_data():
    """
    This function reads the data from the API through the get_data_as_list 
    fucntion and returns an my_dataay containing a visual representation of the level of pollution at each hour
    @return date: string of the date
    @return graph_output: 2D array of hours and a string of charaters representing the pollution level at the time
    """
    # Your code goes here
    # Call function to retrieve data
    my_data = get_data_as_list()
    # Seprate date and hour
    date = my_data[0][0].split()[0]
    graph_output = []
    # Iterates threough each recorded hour
    for j in my_data:
        # Create mini array
        data_point = []
        # Add to mini array
        data_point.append(j[0].split()[1])
        # Create a string representing the level of pollution
        chart = ''
        # iterates for n//3 times per hour where n is the pollutant level
        for i in range (0,int(round(j[1])),3):
            chart += ('-')
        # Add to mini array
        data_point.append(chart)
        # Adds mini array to array to represent the whole day
        graph_output.append(data_point)    
    return date,graph_output
        
 
def dangerous_hours(danger_level):
    """
    This function reads the data from the API through the get_data_as_list fucntion and takes in a danger level 
    as an integer.vIt outputs two lists, one containing safe pollutant hour and one containing unsafe polluant 
    hours
    @param danger_level: integer of the level of pollution where it becomes dangerous
    @return safe_hours: 2D array of hours and pollution level below danger_level
    @return unsafe_hours: 2D array of hours and pollution level above danger_level
    """
    # Your code goes here
    # Call function to retrieve data
    my_data = get_data_as_list()
    # All hours and data points that are below the level are added to one list and the ones above to anothr
    safe_hours = [x for x in my_data if x[1] < danger_level]
    unsafe_hours = [x for x in my_data if x[1] >= danger_level]
    return safe_hours,unsafe_hours


def sort_data():
    """
    This function reads the data from the API through the get_data_as_list fucntion and outputs the sorted list.
    The function sorts the list using a bubble sort, sorting from smallest to largest
    @return my_data: 2D array of sorted hours and pollution level
    """
    # Your code goes here
    # Call function to retrieve data
    my_data = get_data_as_list()
    # Traverse through all my_data elements
    for i in range(len(my_data)):
        for j in range(0, (len(my_data))-i-1):
            # Swap if the element found is greater than the next element
            if my_data[j][1] > my_data[j + 1][1]:
                my_data[j], my_data[j + 1] = my_data[j + 1], my_data[j]
    return my_data



