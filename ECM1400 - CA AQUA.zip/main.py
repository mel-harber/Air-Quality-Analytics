# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification

from reporting import *
from intelligence import *
from monitoring import *
from utils import *
import csv

# Open csv files as 2D arrays then make them into a single dictionary
with open ('data/Pollution-London Harlington.csv' , newline='' ) as csvfile:
    dataListHarl = list(csv.reader(csvfile))
with open ('data/Pollution-London Marylebone Road.csv' , newline='' ) as csvfile:
    dataListMarl = list(csv.reader(csvfile))
with open ('data/Pollution-London N Kensington.csv' , newline='' ) as csvfile:
    dataListKens = list(csv.reader(csvfile))
# Combine into dictionary
dData = {'Harlington':dataListHarl,'Marylebone':dataListMarl,'Kensington':dataListKens}


def main_menu():
    """This functions doens't have any inputs and is executed when this file is run, it provides mutliple options 
    of modules to be executed. The function calls another function that depends on the user's input"""
    # Your code goes here
    # User is provided with the different modules to select from
    sUserInput = (input('R - Access the PR module\nI - Access the MI module\nM - Access the RM module\nA - Print the About text\nQ - Quit the application\nSelect menu option:\n')).upper()
    # Corresponding function is called depending on the user's input
    if sUserInput == 'R':
        reporting_menu()
    elif sUserInput == 'I':
        intelligence_menu()
    elif sUserInput == 'M':
        monitoring_menu()
    elif sUserInput == 'A':
        about()
    elif sUserInput == 'Q':
        quit()    
    else:
        print('Invalid input')
        main_menu()


def reporting_menu():
    """This functions doens't have any inputs and is executed when the user selects option 'R', 
    it provides mutliple function to be executed all based around Pollution-London monitoring stations data.
    The outputs depends on the function selected. Once finished it returns the user to the main menu""" 
    # Your code goes here
    # User is provided with 7 functions to select from
    sReportingFunc = (input('DA - Daily Average\nDM - Daily Median\nHA - Hourly Average\nMA - Monthly Average\nPH - Peak Hour Data\nCM - Count Missing Data\nFM - Fill Missing Data\nSelect menu option:\n')).upper() 
    # If the user enters an input that is not an options then they are returned to the main menu
    if sReportingFunc not in ['DA','DM','HA','MA','PH','CM','FM']:
        print ('non menu item selected') 
        main_menu()
    # User selects monitoring station to view data for 
    sStation = (input('Select a monitoring station:\nH - Harlington\nM - Marylebone\nK - Kensington\n')).upper()
    if sStation == 'H':
        mointoring_station = 'Harlington'
    elif sStation == 'M':
        mointoring_station = 'Marylebone'
    elif sStation == 'K':
        mointoring_station = 'Kensington'
    else:
        print('not a station')
        main_menu()
    # User selects pollution to view data for 
    sSelectPollutant = input('Select a pollutant:\n1. no\n2. pm10\n3. pm25\n')
    if sSelectPollutant == '1':
        pollutant = 'no'
    elif sSelectPollutant == '2':
        pollutant = 'pm25'
    elif sSelectPollutant == '3':
        pollutant = 'pm25'
    else:
        print('not an option') 
        main_menu()
    # The corresponding function is called depending on the user's input, passing it the corresponding values
    match sReportingFunc:
        case "DA":
            print(daily_average(dData, mointoring_station, pollutant))
        case "DM":
            print(daily_median(dData, mointoring_station, pollutant))   
        case "HA":
            print(hourly_average(dData, mointoring_station, pollutant))
        case "MA":
            print(monthly_average(dData, mointoring_station, pollutant))  
        case "PH":
            input_date = input('Select a date in the form YYYY-MM-DD:\n')
            print(peak_hour_date(dData, input_date, mointoring_station,pollutant))    
        case "CM": 
            print('There are',count_missing_data(dData, mointoring_station,pollutant),'missing data values') 
        case "FM": 
            new_value = input('New value:\n')
            newData = fill_missing_data(dData, new_value, mointoring_station,pollutant)
            print('Data added') 
    main_menu()
        

def intelligence_menu():
    """This functions doens't have any inputs and is executed when the user selects option 'I',it provides mutliple 
    function to be executed all based around the Marylebone Road area map.The outputs depends on the function 
    selected, most are saved as files. Once finished it returns the user to the main menu"""
    # Your code goes here
    # User is provided with 5 functions to select from
    print('This menu option returns data about a two-dimensional image of the Marylebone Road area map containing a twodimensional pixel (picture element) array. In this image, different pavement types are highlighted in different colours, for example, red colour for pavement in both directions.')
    sIntelligenceFunc = (input('FR - Find Red Pixels\nFC - Find Cyan Pixels\nDC - Detected Connected Components\nSDC - Sort Detected Connected Components\nSelect menu option:\n')).upper() 
    # If the user enters an input that is not an options then they are returned to the main menu
    if sIntelligenceFunc not in ['FR','FC','DC','SDC']:
        print ('non menu item selected') 
        main_menu() 
    # The corresponding function is called depending on the user's input
    match sIntelligenceFunc:
        case "FR":
            find_red_pixels('map.png')
            print('map-red-pixels.jpg successfully saved!')
        case "FC":
            find_cyan_pixels('map.png')
            print('map-cyan-pixels.jpg successfully saved!')
        case "DC":
            colour_pxl = input('Input either:\nR - red pixels\nC - cyan pixels\n').upper() 
            if colour_pxl == 'R':
                detect_connected_components(find_red_pixels('map.png'))
            else:
                detect_connected_components(find_cyan_pixels('map.png'))
            print('cc-output-2a.txt successfully saved!')
        case "SDC":
            colour_pxl = input('Input either:\nR - red pixels\nC - cyan pixels\n').upper()
            if colour_pxl == 'R':
                detect_connected_components_sorted(detect_connected_components(find_red_pixels('map.png')))
            else:
                detect_connected_components_sorted(detect_connected_components(find_cyan_pixels('map.png')))            
            print('cc-output-2b.txt and cc-top-2.jpg successfully saved!')
    
    # The user is returned to the main menu once the function has been executed
    main_menu()


def monitoring_menu():
    """This functions doens't have any inputs and is executed when the user selects option 'M', 
    it provides mutliple function to be executed all based around the LondonAir AirQuality API.
    The outputs depends on the function selected. Once finished it returns the user to the main menu"""
    # Your code goes here
    # User is provided with 5 functions to select from
    print('This menu option returns data about the LondonAir API using its AirQuality API')
    sMonitoringFunc = (input('GL - Get List of Data\nCV - Calculate Variance\nVD - Visualise data\nDH - Dangerous Hours\nSD - Sort Data\nSelect menu option:\n')).upper() 
    # If the user enters an input that is not an options then they are returned to the main menu
    if sMonitoringFunc not in ['GL','CV','VD','DH','SD']:
        print ('non menu item selected') 
        main_menu() 
    # The corresponding function is called depending on the user's input
    match sMonitoringFunc:
        case "GL":
            print('This is the data currently being retreived by the API\n',get_data_as_list())
        case "CV":
            print('The variance of the pollution level of the day so far is ', calc_variance())
        case "VD":
            print('This is a visual representation of the pollution level each hour of the day so far recorded')
            date,graph_output = visualise_data()
            print (date)
            for i in graph_output:
                print (i[0],': ',i[1])
        case "DH":
            input_date = input('Input the pollutent level at which the pollutant becomes dangerous\n')
            safe_hours,unsafe_hours = dangerous_hours(float(input_date))
            print('The safe hours and their pollution level are:\n',safe_hours,'\nThe unsafe hours and their pollution level are:\n',unsafe_hours)
        case "SD":
            print('The hours and their pollutant level ordered from smallest to largest')
            for i in sort_data():
                print(i)
    # The user is returned to the main menu once the function has been executed
    main_menu()
    

def about():
    """"This functions doens't have any inputs and is executed when the user selects option 'A', 
    it outputs the module code and my candidate number."""
    # Your code goes here
    print('ECM1400', 'Cantidate number: 245977')
    # The user is returned to the main menu
    main_menu()


def quit():
    """This functions doens't have any inputs or outputs and is executed when the user selects option 'Q', 
    it termiantes the program."""
    # Your code goes here
    import sys
    sys.exit()



if __name__ == '__main__':
    main_menu()



