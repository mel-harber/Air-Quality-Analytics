import pytest
import numpy 
from intelligence import find_red_pixels, find_cyan_pixels, detect_connected_components

# Intelligence tests
# Test find red pixels function
def test_find_red():
   # Tests if returned value is a numpy array and is the same size as the map
   assert type(find_red_pixels('map.png')) == numpy.ndarray
   assert find_red_pixels('map.png').shape == (1140, 1053)

# Test find cyan pixels function
def test_find_cyan():
   # Tests if returned value is a numpy array and is the same size as the map
   assert type(find_cyan_pixels('map.png')) == numpy.ndarray
   assert find_cyan_pixels('map.png').shape == (1140, 1053)

# Test detect connected components function
def test_detect_connected_components():
   # Tests if returned value is a numpy array and is the same size as the passed image
   assert type(detect_connected_components('map-red-pixels.jpg')) == numpy.ndarray
   assert detect_connected_components('map-cyan-pixels.jpg').shape == (1140, 1053)

