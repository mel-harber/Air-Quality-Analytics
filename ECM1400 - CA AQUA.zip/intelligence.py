# This is a template. 
# You should modify the functions below to match
# the signatures determined by the pronect specification

import numpy as np
from skimage import io
import matplotlib.pyplot as plt 
from utils import *

def find_red_pixels(map_filename, upper_threshold=100, lower_threshold=50):
    """
    This function takes a map as an input as well as set parameters for the upper and lower threshold. 
    It returns a 2D array in numpy representing the red pixels from the original map, and writed the 2D array into 
    a jpg file
    @param map_filename: string of the file name 
    @param upper_threshold: interger set to 100
    @param lower_threshold: integer set to 50
    @return binary_array: 2D array of 1s and 0s representing where the coloured pixels are in the image
    """
    # Your code goes here
    # Imports image as a numpy array
    img_np = io.imread('data/'+map_filename)
    # Set values of black and white pixels to be allocated later
    black_pixel = [0,0,0]
    white_pixel = [255,255,255]
    # Converts numpy array to a 2D array
    img_array = []
    for i in img_np:
        arr = []
        for n in i:
            arr.append(n)
        img_array.append(arr)
    # Create 2D array of black and white pixels highlighting where the red pixels are
    red_array = []
    # Create a 2D array of 1s and 0s signifying where there are coloured pixels
    binary_array = []
    for row in img_array:
        red_row = []
        binary_row = []
        for column in row:
            # rgb values for the current pixel
            r = int(column[0])
            g = int(column[1])
            b = int(column[2])
            # If the pixel is red make it white
            if r > upper_threshold and g < lower_threshold and b < lower_threshold:
                red_column = white_pixel
                binary_col = 1
            else:
                red_column = black_pixel
                binary_col = 0
            red_row.append(red_column)
            binary_row.append(binary_col)
        red_array.append(red_row)
        binary_array.append(binary_row)
    # Convert array to numoy array
    final_image = np.array(red_array, dtype=np.uint8) 
    # Save numpy array as an image   
    io.imsave("map-red-pixels.jpg", final_image)
    binary_array = np.array(binary_array)
    return binary_array
    



def find_cyan_pixels(map_filename, upper_threshold=100, lower_threshold=50):
    """
    This function takes a map as an input as well as set parameters for the upper and lower threshold. 
    It returns a 2D array in numpy representing the cyan pixels from the original map, and writed the 2D array into 
    a jpg file
    @param map_filename: string of the file name 
    @param upper_threshold: interger set to 100
    @param lower_threshold: integer set to 50
    @return binary_array: 2D array of 1s and 0s representing where the coloured pixels are in the image
    """
    # Your code goes here
    # Imports image as a numpy array
    img_np = io.imread('data/'+map_filename)
    # Set values of black and white pixels to be allocated later
    black_pixel = [0,0,0]
    white_pixel = [255,255,255]
    # Converts numpy array to a 2D array
    img_array = []
    for i in img_np:
        arr = []
        for n in i:
            arr.append(n)
        img_array.append(arr)
    # Create 2D array of black and white pixels highlighting where the cyan pixels are
    cyan_array = []
    # Create a 2D array of 1s and 0s signifying where there are coloured pixels
    binary_array = []    
    for row in img_array:
        cyan_row = []
        binary_row = []
        for column in row:
            # rgb values for the current pixel
            r = int(column[0])
            g = int(column[1])
            b = int(column[2])
            # If the pixel is cyan make it white
            if r < lower_threshold and g > upper_threshold and b > upper_threshold:
                cyan_column = white_pixel
                binary_col = 1
            else:
                cyan_column = black_pixel
                binary_col = 0
            cyan_row.append(cyan_column)
            binary_row.append(binary_col)
        cyan_array.append(cyan_row)
        binary_array.append(binary_row)
    # Convert array to numoy array
    final_image = np.array(cyan_array, dtype=np.uint8)    
    # Save numpy array as an image 
    io.imsave("map-cyan-pixels.jpg", final_image)
    binary_array = np.array(binary_array)
    return binary_array



def detect_connected_components(IMG):
    """
    This function takes an imgage as an input, in this case it is either the map of red or cyan pixels.
    It calculates the size and the number of connected components in the image and returns them to a text file.
    @param IMG: string naming an image file
    @return MARK: 2D array representing where the coloured pixels are in the image 
    """
    # Your code goes here
    # Image is imported as a 2D array
    img_shape = IMG.shape
    # Makes a numpy array the same size as the image, filled with zeros
    MARK = np.zeros((img_shape[0],img_shape[1]),np.uint16)
    # Sets variable to store the coords of pixels in current connected component
    Q = np.ndarray((0,2))
    component_no = 1 
    # Array to store all the pixels in a component
    component_len = []
    # Iterates through each pixel in the image
    for x in range (img_shape[0]):
        for y in range (img_shape[1]):
            # Sets variable for current pixel
            # If the pixel is unvisited and paved
            if MARK[x][y] == 0 and IMG[x][y] == 1: 
                component_size = 1
                # Mark as visited
                MARK[x][y] = component_no
                # Current pixel is added to the Q queue
                Q = np.append(Q,[[x,y]],axis=0)
                # Look if there is any connected pixels
                while len(Q) > 0:
                    # Remove the first item mn from the queue Q
                    mn = [int(Q[-1][0]), int(Q[-1][1])]
                    Q = np.delete(Q,-1,axis=0)
                    # Traverse through the neighbouring pixels
                    for s in range(mn[0]-1,mn[0]+2):
                        for t in range(mn[1]-1,mn[1]+2):
                            # If adjacent to the original pixel
                            if 0<s<img_shape[0] and 0<t<img_shape[1]:
                                # If the pixel is unvisited and paved
                                if MARK[s][t] == 0 and IMG[s][t] == 1: 
                                    # Mark as visited
                                    MARK[s][t] = component_no
                                    # Adds current pixel to Q if all requirements have been met
                                    Q = np.append(Q,[[s,t]],axis=0)
                                    component_size +=1
                # Adds mini array contining the component number and the size of the component
                component_len.append([component_no,component_size])
                # Component number is incremented
                component_no +=1
    # Calls function to wrtie connected componets to a text file in the correct format
    write(component_len,'cc-output-2a.txt')
    return MARK



def detect_connected_components_sorted(MARK):
    """
    This function reads MARK from the detect connected components function and outputs a list of sorted 
    connected components to a text file and outputs the largest 2 connected components to a jpg file
    @param MARK: 2D array representing where the coloured pixels are in the image 
    """
    # Your code goes here
    # Find all the components numbers and their lengths
    component_len = find_component_pairs(MARK)
    # Sorts list of connected components by component length
    sorted_len = sorted_array(component_len)
    # Saves sorted list to a text file
    write(sorted_len,'cc-output-2b.txt')
    # Set pixel values for black and white pixels
    black_pixel = [0,0,0]
    white_pixel = [255,255,255]
    # Make an empty numpy array the same size as MARK 
    shape = MARK.shape
    largest_components = np.empty((shape[0],shape[1],3),np.uint8)
    # Loop through image and allocate white pixels where the 2 largest connected components are
    for x in range(shape[0]):
        for y in range(shape[1]):
            if MARK[x][y] == sorted_len[0][0] or MARK[x][y] == sorted_len[1][0]:
                largest_components[x][y] = white_pixel
            else:
                largest_components[x][y] = black_pixel
    # Save image as a jpg file
    plt.imsave('cc-top-2.jpg',largest_components)
    

def write(values, filename):
    """
    This function takes a 2D array and a file name as it's input and saves the array to the file in the correct
    format.
    @param values: 2D array of values to be stored
    @param filename: string of the name of the file to be used
    """
    # Creates or opes file passed to the function
    f = open(filename,'w')
    # Writes data to the file
    for i in range (len(values)):
        f.write('Connected Components '+str(values[i][0])+', number of pixels = '+str(values[i][1])+'\n')
    f.write('Total number of connected components = '+ str(len(values)))
    # Saves and closes the file
    f.close()


def find_component_pairs(MARK):
    """
    This function takes the MARK array as an input and returns a 2D array of component numbers and their 
    lengths
    @param MARK: 2D array representing where the coloured pixels are in the image
    @return component_length: 2D array representing all the connected components and their size 
    """
    # Convert to 1D array 
    mark_1d = MARK.flatten()
    # Remove all duplicates from the list
    unique_set = []
    for i in mark_1d:
        if i not in unique_set:
            unique_set.append(i)
    # Create 2D list of component mubers
    component_length = []
    for i in range(1,len(unique_set)):
        component_length.append([i,0])
    # Traverse through each pixel in the image
    for x in range (MARK.shape[0]):
        for y in range(MARK.shape[1]):
            p = MARK[x][y]
            if p != 0:
                for i in unique_set:
                    if i == p:
                        # Write component length to the 2D array
                        component_length[i-1][1] += 1
    return component_length